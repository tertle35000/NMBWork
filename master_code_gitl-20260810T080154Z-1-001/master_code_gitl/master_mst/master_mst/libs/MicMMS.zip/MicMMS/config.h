#ifndef CONFIG_H
#define CONFIG_H
/*------------------- Information Program -------------------*/
//  MicMMS version 2.0.3  (Version code)
/*----------------------------------------------------------*/

#define Pinled1 1                // LED for Detected the Publish data
#define Pinled2 2                // LED for Connection Internet
#define rsRx 18                  // Pin for Serial RS232/RS485 UART Rx 18
#define rsTx 17                  // Pin for Serial RS232/RS485 UART Tx 17
#define SaveDisconnectTime 1000  // Time in ms for save disconnection

#if CONFIG_IDF_TARGET_ESP32
#define ESP32  1
#elif CONFIG_IDF_TARGET_ESP32S2
#define ESP32  2
#elif CONFIG_IDF_TARGET_ESP32S3
#define ESP32  3
#elif CONFIG_IDF_TARGET_ESP32C6
#define ESP32  4
#else
#define ESP32  5
#endif

/*--------- Topics to Publish MQTT Broker ---------*/
char* topic_pub_1 = "data";  //data/mic/test/a001
char* topic_pub_2 = "status";
char* topic_pub_3 = "alarm";
char* topic_esp_health = "esp_health";
char* topic_broke_modbus = "mqtt";
//  char* topic_sub_1 = "sub_1";

/*--------- Timer config ---------*/
const uint16_t itr_modbus = 100;    // ms   0.1s
const uint16_t itr_fnc_1 = 1000;    // ms   1s
const uint16_t itr_fnc_2 = 1000;    // ms
const uint16_t itr_fnc_3 = 1000;    // ms
const uint16_t itr_esp = 20000;     // ms    20s
const uint16_t itr_network = 5000;  // ms  5s
const uint16_t itr_bro_mod = 5000;  // ms

/*--------- Variable Declaration ---------*/
const int num_got_data = 170;
uint16_t got_data[num_got_data];
float init_heap;
uint16_t bkr_connect, modb_check;
uint16_t query_check1, query_check2;
uint16_t query_temp1, query_temp2, tigger_1 = 1;
int total_data, Add_convert = 65536;
int16_t total_data1;
int16_t de_cimal;
int total_data2, de_cimal1;
uint8_t result;
String prv_status, status;
String alarm_;
String Wos_ttl;
String Rx_datasub;
unsigned long long prv_time = 0;
unsigned long long prv_time_1 = 0;
unsigned long long prv_time_2 = 0;
uint16_t heap_cnt1, heap_cnt2, heap_cnt3;
float ct_fn1, ct_fn2, ct_fn3, ct_read;
uint16_t ct_read_cnt, ct_fn1_cnt, ct_fn2_cnt, ct_fn3_cnt;
/*--------- Number Time config CPU ---------*/
const uint16_t ct_read_ = 400;        //400 microsec
const unsigned int ct_fn1_ = 100000;  //100  ms
const unsigned int ct_fn2_ = 100000;  //100 ms
const unsigned int ct_fn3_ = 100000;  //100 ms

String def_tb[][5] = {
  /*------ name||address||type||value||prv_value ------*/
  /*------- type for separate detail of data -------*/
  { "SET UP", "1", "1", "", "" },
  { "WAIT QC", "2", "1", "", "" },
  { "MACHINE MANTE", "3", "1", "", "" },
  { "PLAN STOP", "4", "1", "", "" },
  { "WAIT PART", "5", "1", "", "" },
  { "MC_RUN", "6", "1", "", "" },
  { "MC_STOP", "7", "1", "", "" },
  { "NO-WORK", "21", "2", "", "" },
  { "C1-HOPPER EMPTY", "22", "2", "", "" },
  { "C2-HOPPER EMPTY", "23", "2", "", "" },
  { "C3-HOPPER EMPTY", "24", "2", "", "" },
  { "C4-HOPPER EMPTY", "25", "2", "", "" },
  { "C5-HOPPER EMPTY", "26", "2", "", "" },
  { "C1-HOPPER EMPTY(3ball)", "27", "2", "", "" },
  { "C2-HOPPER EMPTY(3ball)", "28", "2", "", "" },
  { "C3-HOPPER EMPTY(3ball)", "29", "2", "", "" },
  { "LOT QTY.COMPLETED.", "30", "2", "", "" },
  { "TRAY QTY.COMPLETED.", "31", "2", "", "" },
  { "R.P.SAMPLE QTY.COMPLETED.", "32", "2", "", "" },
  { "D1 RTN'R EMPTY", "33", "2", "", "" },
  { "D2 RTN'R EMPTY", "34", "2", "", "" },
  { "D1 RTNR WAIT", "35", "2", "", "" },
  { "D2 RTNR WAIT", "36", "2", "", "" },
  { "AIR LOW PRESSURE", "37", "2", "", "" },
  { "EMG.STOP", "38", "2", "", "" },
  { "STATION ERROR", "39", "2", "", "" },
  { "SERVO &INDEX ERROR", "40", "2", "", "" },
  { "CAMAERA CHECK NG", "41", "2", "", "" },
  { "BALL CHECK NG", "42", "2", "", "" },
  { "RETAINER NG", "43", "2", "", "" },
  { "REMNANTS", "44", "2", "", "" },
  { "908 C1-SUPPLY ERROR", "45", "2", "", "" },
  { "909 C2-SUPPLY ERROR", "46", "2", "", "" },
  { "910 C3-SUPPLY ERROR", "47", "2", "", "" },
  { "D1 SUPPLY W-CHECK ERROR", "48", "2", "", "" },
  { "D2 SUPPLY W-CHECK ERROR", "49", "2", "", "" },
  { "W.TRANSFER W-CHECK ERROR", "50", "2", "", "" },
  { "C1-EMPTY", "51", "2", "", "" },
  { "C2-EMPTY", "52", "2", "", "" },
  { "C3-EMPTY", "53", "2", "", "" },
  { "C4-EMPTY", "54", "2", "", "" },
  { "C5-EMPTY", "55", "2", "", "" },
  { "D1 NO-RETAINER", "56", "2", "", "" },
  { "D1 VACUUM MISS", "57", "2", "", "" },
  { "D2 NO-RETAINER", "58", "2", "", "" },
  { "D2 VACUUM MISS", "59", "2", "", "" },
  { "WATING FOR STATION", "60", "2", "", "" },
  { "D1 CHECK CABLE SIGNAL NG", "61", "2", "", "" },
  { "EJECT CHECK CABLE SIGNAL NG", "62", "2", "", "" },
  { "NO WORK IR , OR", "63", "2", "", "" },
  { "BRG MIX PART", "64", "2", "", "" },
  { "CABLE WORK CHUCK NG", "65", "2", "", "" },
  { "COUNTER NG YIELD OVER", "66", "2", "", "" },
  { "STATION NG YIELD OVER", "67", "2", "", "" },
  { "MAIN INDEX CYCLE OVER", "68", "2", "", "" },
  { "PRE P.WORK TAKE UP", "69", "2", "", "" },
  // { "MAIN P.WORK TAKE UP", "70", "2", "", "" },
  // { "C1-EMPTY(3ball)", "71", "2", "", "" },
  // { "C2-EMPTY(3ball)", "72", "2", "", "" },
  // { "C3-EMPTY(3ball)", "73", "2", "", "" },
  // { "WORK SUPP. CYCLE OVER", "74", "2", "", "" },
  // { "C1/C2(C1) B.SUPP CYCLE OVER", "75", "2", "", "" },
  // { "C3(C2) B.SUPP CYCLE OVER", "76", "2", "", "" },
  // { "C4/C5(C3) B.SUPP CYCLE OVER", "77", "2", "", "" },
  // { "O/R HOLD CYCLE OVER", "78", "2", "", "" },
  // { "PRE B.SEPA CYCLE OVER", "79", "2", "", "" },
  // { "B.SEPA CYCLE OVER", "80", "2", "", "" },
  // { "CAMERA CHECK CYCLE OVER", "81", "2", "", "" },
  // { "SEPA CHECK CYCLE OVER", "82", "2", "", "" },
  // { "SD1/D2 SUPP CYCLE OVER", "83", "2", "", "" },
  // { "W.TRNSFER CYCLE OVER", "84", "2", "", "" },
  // { "PRE PRESS CYCLE OVER", "85", "2", "", "" },
  // { "MAIN PRESS CYCLE OVER", "86", "2", "", "" },
  { "yyyy", "88", "0", "", "" },
  { "mm", "89", "0", "", "" },
  { "dd", "90", "0", "", "" },
  { "hh", "91", "0", "", "" },
  { "min", "92", "0", "", "" },
  { "sec", "93", "0", "", "" },
  { "Ball_C1_OK", "98", "3", "", "" },
  { "Ball_C1_OK1", "99", "3", "", "" },
  { "Ball_C2_OK", "100", "3", "", "" },
  { "Ball_C2_OK1", "101", "3", "", "" },
  { "Ball_C3_OK", "102", "3", "", "" },
  { "Ball_C3_OK1", "103", "3", "", "" },
  { "Ball_C4_OK", "104", "3", "", "" },
  { "Ball_C4_OK1", "105", "3", "", "" },
  { "Ball_C5_OK", "106", "3", "", "" },
  { "Ball_C5_OK1", "107", "3", "", "" },
  { "Ball_C1_NG", "108", "3", "", "" },
  { "Ball_C1_NG1", "109", "3", "", "" },
  { "Ball_C2_NG", "110", "3", "", "" },
  { "Ball_C2_NG1", "111", "3", "", "" },
  { "Ball_C3_NG", "112", "3", "", "" },
  { "Ball_C3_NG1", "113", "3", "", "" },
  { "Ball_C4_NG", "114", "3", "", "" },
  { "Ball_C4_NG1", "115", "3", "", "" },
  { "Ball_C5_NG", "116", "3", "", "" },
  { "Ball_C5_NG1", "117", "3", "", "" },
  { "BAll_C1_REMAIN", "118", "3", "", "" },
  { "BAll_C1_REMAIN1", "119", "3", "", "" },
  { "BAll_C2_REMAIN", "120", "3", "", "" },
  { "BAll_C2_REMAIN1", "121", "3", "", "" },
  { "BAll_C3_REMAIN", "122", "3", "", "" },
  { "BAll_C3_REMAIN1", "123", "3", "", "" },
  { "BAll_C4_REMAIN", "124", "3", "", "" },
  { "BAll_C4_REMAIN1", "125", "3", "", "" },
  { "BAll_C5_REMAIN", "126", "3", "", "" },
  { "BAll_C5_REMAIN1", "127", "3", "", "" },
  { "ball_gauge_c1", "70", "4", "", "" },   //keep value
  { "ball_gauge_c11", "71", "4", "", "" },  //keep decimal
  { "ball_gauge_c2", "72", "4", "", "" },
  { "ball_gauge_c21", "73", "4", "", "" },
  { "ball_gauge_c3", "74", "4", "", "" },
  { "ball_gauge_c31", "75", "4", "", "" },
  { "ball_gauge_c4", "76", "4", "", "" },
  { "ball_gauge_c41", "77", "4", "", "" },
  { "ball_gauge_c5", "78", "4", "", "" },
  { "ball_gauge_c51", "79", "4", "", "" },
  { "RTNR_OK", "138", "3", "", "" },
  { "RTNR_OK1", "139", "3", "", "" },
  { "RTNR_NG", "140", "3", "", "" },
  { "RTNR_NG1", "141", "3", "", "" },
  { "BALL_SEPA_NG", "142", "3", "", "" },
  { "BALL_SEPA_NG1", "143", "3", "", "" },
  { "BALL_SHOT_NG", "144", "3", "", "" },
  { "BALL_SHOT_NG1", "145", "3", "", "" },
  { "production_daily_ok", "146", "3", "", "" },
  { "production_daily_ok1", "147", "3", "", "" },
  { "production_daily_ng", "148", "3", "", "" },
  { "production_daily_ng1", "149", "3", "", "" },
  { "average_cycle_time", "80", "5", "", "" },
  { "average_cycle_time1", "81", "5", "", "" },
  { "ball_use_brg", "82", "6", "", "" },
  { "wos_no", "95", "7", "", "" },
  { "wos_no1", "96", "7", "", "" },
  { "wos_no2", "97", "7", "", "" },

};

#endif